alert("welcome to javascript");
